<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Music Report</title>
</head>
<body>
<div class="container">
    <h1>Music Report</h1>
    <p>Pulse Rate: beats per minute (bpm)</p>
    <p>Music Recommendation: </p>
  </div>

</body>
</html>