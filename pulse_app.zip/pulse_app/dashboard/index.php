<?php

require_once("dashboard_servlet.php");

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Client History</title>

    <!-- Montserrat Font -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  </head>
  <body>
    <div class="grid-container">

      <!-- Header -->
      <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
          <span class="material-icons-outlined">menu</span>
        </div>
       
        <div class="header-right">          
          <span class="material-icons-outlined">account_circle</span>
        </div>
      </header>
      <!-- End Header -->

      <!-- Sidebar -->
      <aside id="sidebar">
        <div class="sidebar-title">
          <div class="sidebar-brand">
            <span class="material-icons-outlined">inventory</span> Users Summary
          </div>
          <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
          <li class="sidebar-list-item">
            <?php

            echo "<a href='/pulse_app/welcome.php?user_id=$user_id'>
              <span class='material-icons-outlined'>dashboard</span> Media
            </a>"

            ?>
          </li>
          <li class="sidebar-list-item">
            <a href="/pulse_app/index.php">
              <span class="material-icons-outlined">inventory_2</span> Logout
            </a>
          </li>
         
        </ul>
      </aside>
      <!-- End Sidebar -->

      <!-- Main -->
      <main class="main-container">
        <div class="main-title">
          <p class="font-weight-bold">DASHBOARD</p>
        </div>

        <?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "pulsedb";

// Establish connection with the database
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection establishment
if (mysqli_connect_errno()) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to get mood counts based on time interval
function getMoodCounts($conn, $member_id, $interval) {
    $sql = "SELECT mood, COUNT(mood) AS mood_count 
            FROM reading r, emotion_regulator_app e 
            WHERE r.pulse_app_id = e.pulse_app_id 
              AND e.member_id = ? 
              AND r.timestamp >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
            GROUP BY mood";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $member_id, $interval);
    $stmt->execute();
    $result = $stmt->get_result();

    $moodCounts = ['sad' => 0, 'moderate' => 0, 'happy' => 0];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $moodCounts[$row['mood']] = $row['mood_count'];
        }
    }

    $stmt->close();
    return $moodCounts;
}

$member_id = 1; // Example member_id, you should retrieve this from the session or user input
$interval = isset($_POST['interval']) ? intval($_POST['interval']) : 1; // Default to 1 minute, ensure it's an integer

$moodCounts = getMoodCounts($conn, $member_id, $interval);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mood Bar Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<h2>Select Time Interval</h2>
<form method="post">
    <select name="interval" onchange="this.form.submit()">
        <option value="1" <?php echo $interval == 1 ? 'selected' : ''; ?>>Past 1 minute</option>
        <option value="5" <?php echo $interval == 5 ? 'selected' : ''; ?>>Past 5 minutes</option>
        <option value="10" <?php echo $interval == 10 ? 'selected' : ''; ?>>Past 10 minutes</option>
    </select>
</form>

<canvas id="moodChart" width="400" height="200"></canvas>
<script>
    var ctx = document.getElementById('moodChart').getContext('2d');
    var moodChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Sad', 'Moderate', 'Happy'],
            datasets: [{
                label: 'Mood Counts',
                data: [<?php echo $moodCounts['sad']; ?>, <?php echo $moodCounts['moderate']; ?>, <?php echo $moodCounts['happy']; ?>],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(75, 192, 192, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

</body>
</html>

<?php
$conn->close();
?>


    
  </body>
</html>