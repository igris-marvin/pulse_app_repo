<?php

/* SIGN UP PERSISTENCE FUNCTIONS */

    //PERSISTENCE FUNCTION FOR SIGNUP
    function createUser(
        $user_object,
        $conn
    ) {
        //perform query

        // return null;
    }


    //PERSISTENCE FUNCTION FOR GETTING USERNAMES
    function getUsernames() {

    }

?>