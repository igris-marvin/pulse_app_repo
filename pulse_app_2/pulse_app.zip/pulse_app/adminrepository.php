<?php

function removeUser($member_id, $conn) {

}

function getUserDetails($member_id, $conn) {
    $sql = "SELECT member ";
}

?>