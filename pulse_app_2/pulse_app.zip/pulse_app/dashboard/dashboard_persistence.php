<?php

function getMood($member_id, $conn) {
    $mood = "";

    return $mood;
}

function getBpm($member_id, $conn) {
    $bpm = 0;

    return $bpm;
}

?>