<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Report Pages</title>
    </head>
    <body>
        <ol>
            <li><a href="EmotionDetectionReport.php">Emotion Detection Report</a></li>
            <li><a href="HeartRateTrendsReport.php">Heart Rate Trends Report</a></li>
            <li><a href="music_report.php">Music Report</a></li>
        </ol>
    </body>
</html>